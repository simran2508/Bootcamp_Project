package com.cg.exception;

public class UserGiftDetailsNotFoundException extends Exception {
	
public String toString(UserGiftDetailsNotFoundException e) {
		
		return "User Gift Details Not Found";
	}

}

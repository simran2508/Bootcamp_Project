package com.cg.exception;

public class GiftRecdDetailsNotFoundException extends Exception {

	public String toString(GiftRecdDetailsNotFoundException e) {
		return "Gift Recd Details Not Found";
	}
}

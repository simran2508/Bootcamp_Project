package com.cg.exception;

public class GiftCardNotFoundException extends Exception {

	
public String toString(GiftCardNotFoundException e) {
		
		return "Gift Card Not Found";
	}
}
